import React, { useState, useEffect } from "react";
import "./ResponseGen.css";

const ResponseGen = () => {
  const responses = {
    Happy:
      "It's wonderful to see you in such a positive space! When happiness shines through, it has the power to uplift not only your day but the world around you. Take a moment to appreciate the things that brought you here — your experiences, your choices, your mindset. Keep nurturing this joy, celebrate the big and small wins, and try sharing that energy with someone you care about. You deserve every bit of this happiness 😊",

    Sad:
      "I’m really sorry that you’re feeling low right now. It’s completely okay to have moments where emotions feel heavy — sadness doesn’t make you weak, it simply makes you human. Try not to push your feelings away; allow yourself to acknowledge them gently. You might find comfort in talking to someone you trust or doing something that usually soothes your heart. Remember: feelings pass, brighter moments will always return 💙",

    Angry:
      "It sounds like there’s a lot built up inside you — and that is perfectly valid. Anger often shows up when something matters deeply to us. Before reacting to that feeling, give yourself a small pause. Try grounding yourself with slow breaths and a bit of space from whatever is triggering you. When you’re calmer, you may find better clarity and understanding. Your anger isn’t the problem — how you release it is what matters, and you’re capable of handling it gently 😤➡😌",

    Stressed:
      "Life can feel overwhelming sometimes, especially when responsibilities or emotions stack up faster than we can handle. If you’re stressed, pause for a moment and remind yourself that you’re doing the best you can with what you’ve got. Nothing demands perfection from you — just presence and patience. Break tasks into smaller steps, rest when you can, hydrate, and breathe deeply. You deserve space and care, and one calm moment at a time will guide you forward 🌿",

    Neutral:
      "You're in a balanced emotional space right now — neither too high nor too low — and that’s a perfectly healthy place to be. Neutral moments are opportunities to understand yourself without pressure or overwhelm. This can be a great time to reflect, explore your thoughts, or simply appreciate a quiet mental state. Stay curious, stay mindful, and notice how you shift from here. Every state of mind, even neutral, has value 🌼",

    Calm:
      "Your energy feels centered and steady — that’s a beautiful emotional place to be. Calmness is often rare in the fast pace of daily life, so take a moment to acknowledge and protect it. Use this peaceful state to think clearly, make decisions confidently, or simply enjoy the quiet without rushing toward the next thing. Keep breathing gently and stay connected to whatever brought you this sense of ease 😌"
  };
  const normalizeEmotion = (emo) => {
    if (!emo) return "Neutral";
    const e = emo.toLowerCase();

    if (e.includes("sad")) return "Sad";
    if (e.includes("anger") || e.includes("angry") || e.includes("mad")) return "Angry";
    if (e.includes("stress") || e.includes("pressure")) return "Stressed";
    if (e.includes("happy") || e.includes("good")) return "Happy";
    if (e.includes("fear")) return "Sad";
    if (e.includes("surprise")) return "Happy";
    if (e.includes("disgust")) return "Angry";

    return "Neutral";
  };
  const uid = localStorage.getItem("uid") || "guest";
  const LS_KEY = (k) => `${uid}_${k}`;
  const getDetectedEmotion = () => {
    const faceRaw = localStorage.getItem(LS_KEY("lastFaceEmotion"));
    const textRaw = localStorage.getItem(LS_KEY("lastTextCategory"));

    const face = normalizeEmotion(faceRaw);
    const text = normalizeEmotion(textRaw);

    if (face && face !== "Neutral") return face;
    if (text && text !== "Neutral") return text;

    return "Neutral";
  };
  const [emotion, setEmotion] = useState(getDetectedEmotion());
  const [response, setResponse] = useState(
    responses[getDetectedEmotion()] || responses.Neutral
  );
  useEffect(() => {
    const interval = setInterval(() => {
      const emo = getDetectedEmotion();
      setEmotion(emo);
      setResponse(responses[emo] || responses.Neutral);
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="resp_page">
      <h2 className="page_title">Chatbot Response Generator</h2>

      <p className="intro">
        AI automatically understands your mood and responds 💬
      </p>

      <div className="resp_box">
        <div className="detect_row">
          <p>
            <strong>Detected Emotion:</strong> {emotion}
          </p>
        </div>

        <div className="output">
          <h3>Chatbot Reply</h3>
          <p className="bubble">{response}</p>
        </div>
      </div>
    </div>
  );
};

export default ResponseGen;
