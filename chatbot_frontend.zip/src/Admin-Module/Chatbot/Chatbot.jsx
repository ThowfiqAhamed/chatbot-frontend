import React, { useState } from "react";
import "./Chatbot.css";
import axios from "axios";

const categories = [
  "Greeting",
  "Stress Support",
  "Sadness Comfort",
  "Anger Management",
  "Motivation",
  "General Help"
];

const Chatbot = () => {
  const [selected, setSelected] = useState(categories[0]);
  const [response, setResponse] = useState("");

  const saveResponse = async () => {
    if (!response.trim()) return;

    const payload = { category: selected, response };

    try {
      await axios.post("http://localhost:8000/chatbot/save", payload);
      alert("Response saved!");
      setResponse("");
    } catch (err) {
      alert("Failed to save");
      console.error(err);
    }
  };

  return (
    <div className="chatbot_page">
      <h2 className="page_title">Chatbot Content & Response</h2>

      <div className="chatbot_layout">
        <div className="category_sidebar">
          {categories.map((cat) => (
            <button
              key={cat}
              className={`cat_btn ${selected === cat ? "active" : ""}`}
              onClick={() => setSelected(cat)}
            >
              {cat}
            </button>
          ))}
        </div>

        <div className="editor_section">
          <h3>Edit Response for:</h3>
          <p className="selected_label">{selected}</p>

          <textarea
            value={response}
            onChange={(e) => setResponse(e.target.value)}
            placeholder="Type or update the chatbot reply here..."
          />

          <button className="save_btn" onClick={saveResponse}>
            Save Response
          </button>
        </div>
      </div>
    </div>
  );
};

export default Chatbot;
