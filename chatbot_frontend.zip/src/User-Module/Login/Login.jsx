import React from "react";
import "./Login.css";
import user from "../../assets/User research.gif";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const Login = () => {
  const navigate = useNavigate();

  const UserInputs = [
    {
      name: "email",
      label: "Email",
      type: "email",
      placeholder: "Enter Your Email",
    },
    {
      name: "password",
      label: "Password",
      type: "password",
      placeholder: "Enter Your Password",
    },
  ];

  const handleLogin = async (e) => {
    e.preventDefault();

    const email = e.target.email.value;
    const password = e.target.password.value;

    try {
      const res = await axios.post(
        "http://127.0.0.1:8000/userLogin",
        { email, password }
      );


      localStorage.setItem("uid", res.data.uid);

      alert("Login Successful!");
      navigate("/user", { replace: true });
    } catch (err) {
      alert("Invalid Email or Password");
    }
  };

  return (
    <form onSubmit={handleLogin}>
      <div className="Login_Parent">
        <div className="Login_Content">
          <img src={user} alt="login" height="100%" />

          <div className="Login_Form">
            <h1>Login</h1>

            <div className="Login_Form_Container_New">
              {UserInputs.map((item) => (
                <div className="Login_Input_Row" key={item.name}>
                  <span className="Login_Texts">{item.label}</span>
                  <input
                    type={item.type}
                    placeholder={item.placeholder}
                    className="Login_Inputs"
                    name={item.name}
                    required
                  />
                </div>
              ))}
            </div>

            <div className="Forgot_Password">
              <span onClick={() => navigate("/forgot")}>
                Forgot Password?
              </span>
            </div>

            <button type="submit" className="Login_Btn">
              Login
            </button>

            <div className="Login_Register_Text">
              <span>
                Don't have an account?
                <b onClick={() => navigate("/register")}> Register</b>
              </span>
            </div>
          </div>
        </div>
      </div>
    </form>
  );
};

export default Login;
