import React, { useEffect, useState } from "react";
import axios from "axios";
import "./Logs.css";

const Logs = () => {
  const [logs, setLogs] = useState([]);
  const fetchLogs = async () => {
    try {
      const res = await axios.get("http://localhost:8000/logs");
      setLogs(res.data);
    } catch (err) {
      console.error("Failed to fetch logs", err);
    }
  };
  const exportLogs = async () => {
    try {
      const res = await axios.get("http://localhost:8000/logs/export");
      const blob = new Blob([res.data], { type: "text/csv" });
      const url = window.URL.createObjectURL(blob);

      const a = document.createElement("a");
      a.href = url;
      a.download = `system_logs_${new Date().toISOString().slice(0, 10)}.csv`;
      a.click();
      window.URL.revokeObjectURL(url);
    } catch (err) {
      console.error("Export failed", err);
      alert("Failed to export logs");
    }
  };

  useEffect(() => {
    fetchLogs();
    const interval = setInterval(fetchLogs, 4000); // refresh every 4s
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="logs_page">
      <h2 className="page_title">Logs & Analytics</h2>

      {/* Stats Section */}
      <div className="log_stats">
        <div className="stat_card">
          <h3>Total Logs</h3>
          <p>{logs.length}</p>
        </div>
        <div className="stat_card">
          <h3>Errors</h3>
          <p className="error">{logs.filter((l) => l.type === "ERROR").length}</p>
        </div>
        <div className="stat_card">
          <h3>Warnings</h3>
          <p className="warn">{logs.filter((l) => l.type === "WARNING").length}</p>
        </div>
        <div className="stat_card">
          <h3>Info Events</h3>
          <p>{logs.filter((l) => l.type === "INFO").length}</p>
        </div>
      </div>
      <div className="log_container">
        <h3>Recent System Activity</h3>
        <ul>
          {logs.length === 0 ? (
            <p className="empty">No logs recorded yet</p>
          ) : (
            logs.map((l, index) => (
              <li key={index} className={l.type.toLowerCase()}>
                <span>[{l.time}]</span> {l.type}: {l.message}
              </li>
            ))
          )}
        </ul>
      </div>

      <button className="export_btn" onClick={exportLogs}>
        Export Logs
      </button>
    </div>
  );
};

export default Logs;
