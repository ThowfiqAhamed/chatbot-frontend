import React from "react";
import "./Register.css";
import user from "../../assets/User research.gif";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const Register = () => {
  const navigate = useNavigate();

  const UserInputs = [
    { name: "username", label: "Username", type: "text", placeholder: "Enter Your Username" },
    { name: "email", label: "Email", type: "email", placeholder: "Enter Your Email" },
    { name: "password", label: "Password", type: "password", placeholder: "Enter Your Password" },
    { name: "confirmPassword", label: "Confirm Password", type: "password", placeholder: "Confirm Your Password" }
  ];

  const handleRegister = async (e) => {
    e.preventDefault();

    const username = e.target.username.value;
    const email = e.target.email.value;
    const password = e.target.password.value;
    const confirmPassword = e.target.confirmPassword.value;

    if (password !== confirmPassword) {
      alert("Password & Confirm Password do not match!");
      return;
    }

    try {
      await axios.post("http://127.0.0.1:8000/userCreate", {
        username,
        email,
        password,
      });

      alert("User Registered Successfully!");
      navigate("/login");
    } catch (err) {
      alert("Registration Failed");
    }
  };

  return (
    <form onSubmit={handleRegister}>
      <div className="Register_Parent">
        <div className="Register_Content">
          <img src={user} alt="register" />

          <div className="Register_Form">
            <h1>Register</h1>

            <div className="Register_Form_Container">
              {UserInputs.map((item) => (
                <div className="Register_Input_Row" key={item.name}>
                  <span className="Register_Label">{item.label}</span>
                  <input
                    type={item.type}
                    placeholder={item.placeholder}
                    className="Register_Input"
                    name={item.name}
                    required  
                  />
                </div>
              ))}
            </div>

            <button type="submit" className="Register_Btn">Register</button>

            <div className="Register_Login_Text">
              <span>
                Already have an account?
                <b onClick={() => navigate("/login")}> Login</b>
              </span>
            </div>

          </div>
        </div>
      </div>
    </form>
  );
};

export default Register;
