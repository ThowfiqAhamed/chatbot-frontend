import React, { useEffect, useState, useRef } from "react";
import { useOutletContext } from "react-router-dom";
import "./Fusion.css";

const Fusion = () => {
  const {
    textDone,
    cameraDone,
    lastTextCategory,
    lastFaceEmotion,
    lastFaceConfidence,
  } = useOutletContext();

  const uid = localStorage.getItem("uid") || "guest";
  const LS_KEY = (k) => `${uid}_${k}`;

  const [finalMood, setFinalMood] = useState(null);
  const [reason, setReason] = useState("");
  const pushedRef = useRef(false);

  // ---------------- READY CHECK ----------------
  const ready =
    (textDone || localStorage.getItem(LS_KEY("textDone")) === "true") &&
    (cameraDone || localStorage.getItem(LS_KEY("cameraDone")) === "true");

  if (!ready) {
    return (
      <div className="fusion_blocked">
        <h2>⚠️ Fusion Locked!</h2>
        <p>Please complete:</p>
        <ul>
          <li>📝 Send one text</li>
          <li>🎥 Detect one emotion</li>
        </ul>
      </div>
    );
  }

  // ---------------- RESTORE VALUES ----------------
  const category =
    lastTextCategory ||
    localStorage.getItem(LS_KEY("lastTextCategory")) ||
    "Neutral";

  const feeling =
    lastFaceEmotion ||
    localStorage.getItem(LS_KEY("lastFaceEmotion")) ||
    "Neutral";

  // 🔥 FIXED CONFIDENCE READ
  const storedConf = localStorage.getItem(LS_KEY("lastFaceConfidence"));
  const confidence =
    typeof lastFaceConfidence === "number" && !isNaN(lastFaceConfidence)
      ? lastFaceConfidence
      : storedConf !== null && !isNaN(Number(storedConf))
      ? Number(storedConf)
      : 0;

  // ---------------- HISTORY ----------------
  const pushHistory = (emotion) => {
    const key = LS_KEY("history");
    const list = JSON.parse(localStorage.getItem(key) || "[]");
    const entry = {
      emotion,
      source: "Fusion",
      time: new Date().toLocaleString(),
    };
    localStorage.setItem(key, JSON.stringify([entry, ...list].slice(0, 50)));
  };

  // ---------------- FUSION API ----------------
  useEffect(() => {
    fetch("http://localhost:8000/fusion/predict", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        text_category: category,
        face_emotion: feeling,
        face_confidence: confidence,
      }),
    })
      .then((res) => res.json())
      .then((data) => {
        setFinalMood(data.final_emotion);
        setReason(data.reason);

        if (!pushedRef.current) {
          pushHistory(data.final_emotion);
          pushedRef.current = true;
        }
      })
      .catch(() => {
        setFinalMood(feeling || category);
        setReason("Fallback logic");
      });
  }, [category, feeling, confidence]);

  if (!finalMood) {
    return <div className="fusion_loading">🔄 Processing fusion...</div>;
  }

  // 🔥 SCORE CONTROL (NO 0/100)
  const score = Math.max(30, Math.round(confidence * 100));

  // ---------------- UI ----------------
  return (
    <div className="fusion_page">
      <h2 className="page_title">Fusion & Emotion Classification</h2>

      <div className="fusion_box">
        <h3>📊 Hybrid Emotion Summary</h3>

        <p>📝 Text Category: <b>{category}</b></p>
        <p>🎥 Camera Emotion: <b>{feeling}</b></p>
        {/* <p>📈 Face Confidence: <b>{Math.round(confidence * 100)}%</b></p> */}

        <hr />

        <div className="fusion_result">
          ❤️ Emotional Score: {score}/100
          <br />
          😀 Overall Mood: <b>{finalMood}</b>
          <br />
          🔗 Reason: {reason}
        </div>
      </div>
    </div>
  );
};

export default Fusion;
