import React, { useEffect, useState } from "react";
import axios from "axios";
import "./Model.css";

const Model = () => {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState("");

  const fetchStats = async () => {
    try {
      const res = await axios.get("http://localhost:8000/model/stats");
      setStats(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  const retrain = async () => {
    try {
      setLoading(true);
      const res = await axios.post("http://localhost:8000/model/retrain");
      setMsg(res.data.message);
      fetchStats();
      setTimeout(() => setMsg(""), 3000);
    } catch {
      setMsg("⚠️ Retrain failed");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStats();
    const interval = setInterval(fetchStats, 3000);
    return () => clearInterval(interval);
  }, []);

  if (!stats) return <p>Loading stats…</p>;

  return (
    <div className="model_page">
      <h2 className="page_title">AI Emotion Detection Model Monitoring</h2>

      <div className="model_grid">
        <div className="model_card"><h3>Accuracy</h3><p>{stats.accuracy}%</p></div>
        <div className="model_card"><h3>Precision</h3><p>{stats.precision}%</p></div>
        <div className="model_card"><h3>Recall</h3><p>{stats.recall}%</p></div>
        <div className="model_card"><h3>F1 Score</h3><p>{stats.f1}%</p></div>
      </div>

      <div className="monitor_row">
        <div className="monitor_box"><h3>Predictions</h3><p>{stats.predictions}</p></div>
        <div className="monitor_box"><h3>Users</h3><p>{stats.users}</p></div>
        <div className="monitor_box">
          <h3>Drift</h3>
          <p className={stats.drift > 0.05 ? "warning_text" : "safe_text"}>
            {stats.drift}
          </p>
        </div>
      </div>

      <button className="update_btn" disabled={loading} onClick={retrain}>
        {loading ? "Training..." : "🔁 Retrain Model"}
      </button>

      {msg && <p className="training_msg">{msg}</p>}
    </div>
  );
};

export default Model;
