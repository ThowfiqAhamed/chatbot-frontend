import { useNavigate, Outlet, useLocation } from "react-router-dom";
import { useState, useEffect } from "react";
import {
  FaCamera,
  FaChartLine,
  FaFolderOpen,
  FaShieldAlt,
  FaHistory,
  FaSignOutAlt
} from "react-icons/fa";

const UserNavbar = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const [showLogoutPopup, setShowLogoutPopup] = useState(false);

  const uid = localStorage.getItem("uid");

  useEffect(() => {
    if (!uid) {
      navigate("/", { replace: true });
    }
  }, [uid, navigate]);

  if (!uid) return null;

  const LS_KEY = (k) => `${uid}_${k}`;

  const [textDone, setTextDone] = useState(false);
  const [cameraDone, setCameraDone] = useState(false);

  useEffect(() => {
    setTextDone(localStorage.getItem(LS_KEY("textDone")) === "true");
    setCameraDone(localStorage.getItem(LS_KEY("cameraDone")) === "true");
  }, [uid]);

  const menuItems = [
    { label: "Text & Camera Input", icon: <FaCamera />, path: "/user" },
    { label: "Emotion Fusion & Classification", icon: <FaChartLine />, path: "/user/fusion" },
    { label: "Chatbot Response Generator", icon: <FaFolderOpen />, path: "/user/response" },
    { label: "Mental Wellness Recommendation System", icon: <FaShieldAlt />, path: "/user/recommend" },
    { label: "User Emotion History", icon: <FaHistory />, path: "/user/history" },
    { label: "Logout", icon: <FaSignOutAlt />, action: "logout" }
  ];

  const handleClick = (item) => {
    if (item.action === "logout") {
      setShowLogoutPopup(true);
      return;
    }

    if (item.path === "/user/fusion") {
      const text = localStorage.getItem(LS_KEY("textDone")) === "true";
      const camera = localStorage.getItem(LS_KEY("cameraDone")) === "true";

      if (!(text && camera)) {
        alert("⚠️ Complete Text AND Camera interaction first!");
        return;
      }
    }

    navigate(item.path);
  };

  const confirmLogout = () => {
    setShowLogoutPopup(false);

    Object.keys(localStorage)
      .filter((key) => key.startsWith(uid + "_"))
      .forEach((key) => localStorage.removeItem(key));

    localStorage.removeItem("uid");
    navigate("/", { replace: true });
  };

  return (
    <div className="Admin_Layout">
      <div className="AdminNav_Parent">
        <h1>User</h1>

        <div className="AdminNav_Container">
          {menuItems.map((item) => (
            <div className="AdminNav_Content" key={item.label}>
              <button
                className={
                  item.path === location.pathname ? "active_menu" : ""
                }
                onClick={() => handleClick(item)}
              >
                <span className="icon">{item.icon}</span>
                {item.label}
              </button>
            </div>
          ))}
        </div>
      </div>

      <div className="AdminNav_Outlet">
        <Outlet
          context={{
            textDone,
            setTextDone,
            cameraDone,
            setCameraDone
          }}
        />
      </div>

      {showLogoutPopup && (
        <div className="logout_modal">
          <div className="logout_box">
            <h3>Are you sure you want to logout?</h3>
            <div className="logout_btns">
              <button onClick={confirmLogout}>Yes</button>
              <button onClick={() => setShowLogoutPopup(false)}>
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default UserNavbar;
