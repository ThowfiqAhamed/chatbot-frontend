import React from "react";
import "./AdminLogin.css";
import { useNavigate } from "react-router-dom";
import admin from "../../assets/Admin.gif";
import axios from "axios";

const AdminLogin = () => {
  const navigate = useNavigate();

  const handleAdminLogin = async (e) => {
    e.preventDefault();

    const email = e.target.email.value;
    const password = e.target.password.value;

    try {
      await axios.post("http://127.0.0.1:8000/adminLogin", {
        email,
        password,
      });

      alert("Admin Logged In Successfully!");
      navigate("/admin");
    } catch (err) {
      alert(err.response?.data?.detail || "Invalid Admin Credentials");
    }
  };

  const UserInputs = [
    {
      name: "email",
      label: "Email",
      type: "email",
      placeholder: "Enter Your Email",
    },
    {
      name: "password",
      label: "Password",
      type: "password",
      placeholder: "Enter Your Password",
    },
  ];

  return (
    <form onSubmit={handleAdminLogin}>
      <div className="Login_Parent">
        <div className="Login_Content">
          <img src={admin} alt="login" height="100%" />

          <div className="Login_Form">
            <h1>Admin Login</h1>

            <div className="Login_Form_Container_New">
              {UserInputs.map((item) => (
                <div className="Login_Input_Row" key={item.name}>
                  <span className="Login_Texts">{item.label}</span>
                  <input
                    type={item.type}
                    placeholder={item.placeholder}
                    className="Login_Inputs"
                    name={item.name}
                    required
                  />
                </div>
              ))}
            </div>

            <button type="submit" className="Login_Btn">
              Login
            </button>
          </div>
        </div>
      </div>
    </form>
  );
};

export default AdminLogin;
