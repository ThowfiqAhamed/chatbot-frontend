import React, { useEffect, useState } from "react";
import "./EmotionTrain.css";

const emotions = [
  "happy",
  "sad",
  "angry",
  "fearful",
  "surprised",
  "disgusted",
  "neutral"
];

const EmotionTrain = () => {
  const [selected, setSelected] = useState("happy");
  const [files, setFiles] = useState([]);
  const [history, setHistory] = useState([]);

  const loadHistory = () => {
    fetch("http://localhost:8000/emotion/training/history")
      .then(res => res.json())
      .then(data => setHistory(Array.isArray(data) ? data : []))
      .catch(() => setHistory([]));
  };

  useEffect(() => {
    loadHistory();
  }, []);

  const uploadImages = async () => {
  if (files.length === 0) return alert("📸 Select at least one image!");

  const formData = new FormData();
  formData.append("emotion", selected);
  files.forEach(f => formData.append("files", f));

  try {
    const res = await fetch("http://localhost:8000/emotion/upload", {
      method: "POST",
      body: formData,
    });

    const data = await res.json();
    console.log("UPLOAD RESPONSE:", data);

    if (data.success) {
      alert("🎉 Upload success");
      setFiles([]);
      loadHistory();
    } else {
      alert("❌ Upload failed: " + data.error);
    }

  } catch (err) {
    console.error(err);
    alert("⚠️ Network error");
  }
};


  return (
    <div className="emotion_page">
      <h2 className="emotion_title">📸 Train Camera Emotion</h2>

      <div className="emotion_layout">
        <div className="emotion_sidebar">
          {emotions.map((emo) => (
            <button
              key={emo}
              className={`emo_btn ${selected === emo ? "active" : ""}`}
              onClick={() => setSelected(emo)}
            >
              {emo.toUpperCase()}
            </button>
          ))}
        </div>

        <div className="editor_section">
          <h3>Upload images for:</h3>
          <p className="selected_emo">{selected.toUpperCase()}</p>

          <input
            type="file"
            accept="image/*"
            multiple
            onChange={(e) => setFiles([...e.target.files])}
          />

          <button className="save_btn" onClick={uploadImages}>
            Upload & Train
          </button>

          {files.length > 0 && (
            <p className="file_count">{files.length} file(s) selected</p>
          )}
        </div>
      </div>

      <h3 className="history_title">📊 Recent Training Samples</h3>
      <div className="history_box">
        {history.length === 0 && <p>No uploads yet</p>}

        <ul>
          {history.map((h, i) => (
            <li key={i}>
              <strong>{h.emotion.toUpperCase()}</strong> — {h.file_path.replace("uploads/emotions/", "")}
              <br />
              <small>{new Date(h.created_at).toLocaleString()}</small>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default EmotionTrain;
