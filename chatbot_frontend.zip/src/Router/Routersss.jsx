import React from 'react'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import MainPage from '../MainPage/MainPage'
import AdminLogin from '../Admin-Module/AdminLogin/AdminLogin'
import Login from '../User-Module/Login/Login'
import Register from '../User-Module/Register/Register'
import Forget from '../User-Module/Forget/Forget'
import AdminNav from '../Admin-Module/AdminNavbar/AdminNav'
import UserNavbar from '../User-Module/UserNavbar/UserNavbar'
import Chatbot from '../Admin-Module/Chatbot/Chatbot'
import Model from '../Admin-Module/Model/Model'
import Logs from '../Admin-Module/Logs/Logs'
// import ChatModule from '../User-Module/Chat-Module/ChatModule'
// import CameraEmotion from '../User-Module/Camera-Emotion/CameraEmotion'
import Fusion from '../User-Module/Fusion/Fusion'
import ResponseGen from '../User-Module/Response-Gen/ResponseGen'
import Recommendation from '../User-Module/Recommendation/Recommendation'
import EmotionHistory from '../User-Module/Emotion-History/EmotionHistory'
import UserContent from '../User-Module/User-Content/UserContent'
import UserLayout from '../User-Module/User-Content/UserLayout'
import EmotionTrain from '../Admin-Module/Emotion-Training/EmotionTrain'
// import UserLayout from '../User-Module/UserLayout/UserLayout';


const Routersss = () => {
  return (
    <>
    <BrowserRouter>
    <Routes>
      <Route path='/' element={<MainPage/>}/>
      <Route path='/adminlogin' element={<AdminLogin/>}/>

       <Route path="/admin" element={<AdminNav />}>
          <Route index element={<Chatbot />} />
          <Route path="history" element={<EmotionTrain/>} />
          <Route path="model" element={<Model/>} />
          <Route path="logs" element={<Logs />} />
       </Route>


      <Route path='/login' element={<Login/>}/>
      <Route path='/register' element={<Register/>}/>
      <Route path='/forgot' element={<Forget/>}/>

     <Route path="/user" element={<UserNavbar />}>
      <Route element={<UserLayout/>}>
      <Route index element={<UserContent />} />
      <Route path="fusion" element={<Fusion />} />
    <Route path="response" element={<ResponseGen />} />
    <Route path="recommend" element={<Recommendation />} />
    <Route path="history" element={<EmotionHistory />} />
  </Route>
</Route>



    </Routes>
    </BrowserRouter>
    </>
  )
}

export default Routersss