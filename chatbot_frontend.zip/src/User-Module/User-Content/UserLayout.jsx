import { Outlet } from "react-router-dom";
import { useState, useEffect } from "react";

const UserLayout = () => {
  const uid = localStorage.getItem("uid");

  const key = (k) => `${uid}_${k}`;

  const [textDone, setTextDone] = useState(false);
  const [cameraDone, setCameraDone] = useState(false);

  const [lastTextCategory, setLastTextCategory] = useState(null);
  const [lastFaceEmotion, setLastFaceEmotion] = useState(null);
  const [lastFaceConfidence, setLastFaceConfidence] = useState(null);

  useEffect(() => {
    if (!uid) return;

    setTextDone(localStorage.getItem(key("textDone")) === "true");
    setCameraDone(localStorage.getItem(key("cameraDone")) === "true");

    setLastTextCategory(localStorage.getItem(key("lastTextCategory")));
    setLastFaceEmotion(localStorage.getItem(key("lastFaceEmotion")));

    const conf = localStorage.getItem(key("lastFaceConfidence"));
    setLastFaceConfidence(conf ? Number(conf) : null);

  }, [uid]);

  return (
    <Outlet
      context={{
        textDone,
        setTextDone,
        cameraDone,
        setCameraDone,
        lastTextCategory,
        setLastTextCategory,
        lastFaceEmotion,
        setLastFaceEmotion,
        lastFaceConfidence,
        setLastFaceConfidence
      }}
    />
  );
};

export default UserLayout;
