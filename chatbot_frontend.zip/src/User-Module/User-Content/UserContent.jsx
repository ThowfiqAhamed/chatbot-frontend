import React, { useState, useEffect, useRef } from "react";
import { useOutletContext } from "react-router-dom";
import "./UserContent.css";

const UserContent = () => {
  const {
    textDone, setTextDone,
    cameraDone, setCameraDone,
    setLastTextCategory,
    setLastFaceEmotion,
    setLastFaceConfidence
  } = useOutletContext();
  const uid = localStorage.getItem("uid");
  if (!uid) return <h2>Please login first</h2>;
  const LS_KEY = (k) => `${uid}_${k}`;
  const [tab, setTab] = useState("chat");
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState([]);
  const [emotion, setEmotion] = useState("🙂 Neutral");
  const [cameraOn, setCameraOn] = useState(false);

  const videoRef = useRef(null);
  const loopRef = useRef(null);
  useEffect(() => {
    const savedMessages = localStorage.getItem(LS_KEY("messages"));
    if (savedMessages) setMessages(JSON.parse(savedMessages));

    const savedTab = localStorage.getItem(LS_KEY("activeTab"));
    if (savedTab) setTab(savedTab);
  }, [uid]);

  const detectCategory = (text) => {
    const t = text.toLowerCase();
    if (t.includes("sad")) return "Sadness Comfort";
    if (t.includes("angry")) return "Anger Management";
    if (t.includes("stress")) return "Stress Support";
    if (t.includes("help")) return "Motivation";
    if (t.includes("hi") || t.includes("hello")) return "Greeting";
    return "General Help";
  };

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMsg = { from: "user", text: input };
    const updated = [...messages, userMsg];

    setMessages(updated);
    localStorage.setItem(LS_KEY("messages"), JSON.stringify(updated));

    const category = detectCategory(input);
    setLastTextCategory(category);
    setTextDone(true);
    localStorage.setItem(LS_KEY("textDone"), "true");
    localStorage.setItem(LS_KEY("lastTextCategory"), category);

    setInput("");

    try {
      const res = await fetch(
        `http://localhost:8000/chatbot/${encodeURIComponent(category)}`
      );
      const data = res.ok ? await res.json() : [];

      const reply = data.length
        ? data[Math.floor(Math.random() * data.length)].response
        : "I'm here for you 💙";

      setMessages(prev => {
        const upd = [...prev, { from: "bot", text: reply, category }];
        localStorage.setItem(LS_KEY("messages"), JSON.stringify(upd));
        return upd;
      });
    } catch {
      setMessages(prev => {
        const upd = [...prev, { from: "bot", text: "Server offline 😔" }];
        localStorage.setItem(LS_KEY("messages"), JSON.stringify(upd));
        return upd;
      });
    }
  };
  const detectEmotionBackend = async () => {
    try {
      const video = videoRef.current;
      if (!video || video.videoWidth === 0) {
        loopRef.current = setTimeout(detectEmotionBackend, 1000);
        return;
      }

      const canvas = document.createElement("canvas");
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      canvas.getContext("2d").drawImage(video, 0, 0);

      const blob = await new Promise(r => canvas.toBlob(r, "image/jpeg"));
      if (!blob) return;

      const formData = new FormData();
      formData.append("file", blob, "frame.jpg");

      const res = await fetch("http://localhost:8000/emotion/predict", {
        method: "POST",
        body: formData,
      });

      const data = await res.json();

      if (data?.emotion) {
        setEmotion(`${data.emoji} ${data.emotion}`);

        setLastFaceEmotion(data.emotion);
        setLastFaceConfidence(data.confidence);

        localStorage.setItem(LS_KEY("lastFaceEmotion"), data.emotion);
        localStorage.setItem(LS_KEY("lastFaceConfidence"), data.confidence);

        if (!cameraDone) {
          setCameraDone(true);
          localStorage.setItem(LS_KEY("cameraDone"), "true");
        }
      }
    } catch {}

    loopRef.current = setTimeout(detectEmotionBackend, 1000);
  };

  const startCamera = async () => {
    const stream = await navigator.mediaDevices.getUserMedia({ video: true });
    videoRef.current.srcObject = stream;
    await videoRef.current.play();
    setCameraOn(true);
    detectEmotionBackend();
  };

  const stopCamera = () => {
    clearTimeout(loopRef.current);
    videoRef.current?.srcObject?.getTracks().forEach(t => t.stop());
    setCameraOn(false);
    setEmotion("🙂 Neutral");
  };

  return (
    <div className="combined_page">
      <h2>Your Emotion Interaction</h2>

      <div className="switch_buttons">
        <button
          className={tab === "chat" ? "active" : ""}
          onClick={() => {
            setTab("chat");
            localStorage.setItem(LS_KEY("activeTab"), "chat");
          }}
        >
          📝 Text Chat
        </button>

        <button
          className={tab === "camera" ? "active" : ""}
          onClick={() => {
            setTab("camera");
            localStorage.setItem(LS_KEY("activeTab"), "camera");
          }}
        >
          🎥 Camera Emotion
        </button>
      </div>

      {tab === "chat" && (
        <div className="chat_page">
          <div className="chat_window">
            {messages.map((m, i) => (
              <div
                key={i}
                className={`msg ${m.from === "user" ? "right" : "left"}`}
              >
                <p>{m.text}</p>
                {m.category && <small>{m.category}</small>}
              </div>
            ))}
          </div>

          <div className="chat_input">
            <input
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => e.key === "Enter" && handleSend()}
            />
            <button onClick={handleSend}>Send</button>
          </div>
        </div>
      )}
      {tab === "camera" && (
        <div className="cam_page">
          <div className="cam_left">
            <video
              ref={videoRef}
              autoPlay
              muted
              playsInline
              className="video_feed"
            />
          </div>

          <div className="cam_right">
            <h3 className="detect_title">Detected Emotion</h3>

            <div className="emotion_value">{emotion}</div>

            {!cameraOn ? (
              <button className="start_btn" onClick={startCamera}>
                Start Detection
              </button>
            ) : (
              <button className="stop_btn" onClick={stopCamera}>
                Stop Camera
              </button>
            )}
          </div>
        </div>
      )}

      <div className="progress_status">
        📝 Text: {textDone ? "✔ Done" : "❌ Pending"} |
        🎥 Camera: {cameraDone ? "✔ Done" : "❌ Pending"}
      </div>
    </div>
  );
};

export default UserContent;
