import React from "react";
import "./Forget.css";
import user from "../../assets/User research.gif";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const Forget = () => {
  const navigate = useNavigate();

  const handleUpdate = async (e) => {
    e.preventDefault();

    const email = e.target.email.value;
    const password = e.target.password.value;
    const confirmPassword = e.target.confirmPassword.value;

    if (password !== confirmPassword) {
      alert("Password & Confirm Password do not match!");
      return;
    }

    try {
      await axios.put("http://127.0.0.1:8000/userUpdate", {
        email,
        password,
      });

      alert("Password Updated Successfully!");
      navigate("/login");
    } catch (err) {
      alert(err.response?.data?.detail || "Update failed");
    }
  };

  const UserInputs = [
    { name: "email", label: "Email", type: "email", placeholder: "Enter Your Email" },
    { name: "password", label: "Password", type: "password", placeholder: "Enter Your Password" },
    { name: "confirmPassword", label: "Confirm Password", type: "password", placeholder: "Confirm Your Password" }
  ];

  return (
    <form onSubmit={handleUpdate}>
      <div className="Forgot_Parent">
        <div className="Forgot_Content">

          <img src={user} alt="Forgot" />

          <div className="Forgot_Form">
            <h1>Update</h1>

            <div className="Forgot_Form_Container">
              {UserInputs.map((item) => (
                <div className="Forgot_Input_Row" key={item.name}>
                  <span className="Forgot_Label">{item.label}</span>
                  <input
                    type={item.type}
                    placeholder={item.placeholder}
                    className="Forgot_Input"
                    name={item.name}
                    required
                  />
                </div>
              ))}
            </div>

            <button type="submit" className="Forgot_Btn">Update</button>

          </div>
        </div>
      </div>
    </form>
  );
};

export default Forget;
