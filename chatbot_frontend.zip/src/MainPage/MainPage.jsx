import React from 'react'
import "./MainPage.css"
import admin from "../assets/Admin.gif"
import user from "../assets/User research.gif"
import { useNavigate } from 'react-router-dom'
const MainPage = () => {
  const navigate=useNavigate()
  return (
    <div className='MainPage_Parent'>
        <div className="MainPage_Continer">
            <div className="MainPage_Content" onClick={()=>navigate("/adminlogin")}>
              <img src={admin} alt="" height={"100%"} width={"100%"}/>
              <button>Admin</button>
            </div>
            <div className="MainPage_Content" onClick={()=>navigate("/login")}>
              <img src={user} alt="" height={"100%"} width={"100%"}/>
              <button>User</button>
            </div>
        </div>
    </div>
  )
}

export default MainPage