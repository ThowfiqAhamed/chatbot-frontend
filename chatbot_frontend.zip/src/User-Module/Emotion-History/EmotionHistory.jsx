import React, { useState, useEffect } from "react";
import "./EmotionHistory.css";

const EmotionHistory = () => {
  const uid = localStorage.getItem("uid") || "guest";
  const LS_KEY = (k) => `${uid}_${k}`;
  const [history, setHistory] = useState([]);
  const normalizeClass = (emo) => {
    if (!emo) return "neutral";
    return emo.toLowerCase().replace(/\s+/g, "");
  };

  useEffect(() => {
    const loadHistory = () => {
      const stored = JSON.parse(
        localStorage.getItem(LS_KEY("history")) || "[]"
      );
      setHistory(stored);
    };

    loadHistory();
    const interval = setInterval(loadHistory, 2000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="hist_page">
      <h2 className="page_title">Emotion History Timeline</h2>

      <p className="intro">
        Review your emotional pattern from text, face & fusion.
      </p>

      <div className="timeline_box">
        <h3>Recent Emotion Logs</h3>

        {history.length === 0 && (
          <p className="empty">No history yet. Start interacting!</p>
        )}

        <ul>
          {history.map((item, index) => (
            <li key={index} className={normalizeClass(item.emotion)}>
              <div className="dot"></div>
              <div className="entry">
                <p className="emo">{item.emotion}</p>
                <p className="src">{item.source}</p>
                <p className="time">{item.time}</p>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default EmotionHistory;
