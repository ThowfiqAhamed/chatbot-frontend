import React, { useState } from "react";
import "./Recommendation.css";

const Recommendation = () => {
  const wellnessTips = {
    Happy: [
      "Keep spreading positivity! 🌟",
      "Celebrate your wins — even the small ones 🎉",
      "Share your joy with someone today 😊",
    ],
    Sad: [
      "Take a deep breath. You're not alone 💙",
      "Write down what you're feeling — it can help 😔",
      "Talk to someone you trust 🤝",
    ],
    Angry: [
      "Pause and take 3 slow breaths 😤➡😌",
      "Step away from the situation for a moment 🚶",
      "Write down what triggered your anger ✍️",
    ],
    Stressed: [
      "Close your eyes and take slow deep breaths 🌬",
      "Try a short walk or light stretch 🧘",
      "Drink water and rest your mind 💧",
    ],
    Neutral: [
      "Check in with yourself — how are you feeling now? 🙂",
      "Do one activity you enjoy 🎮",
      "Take a mindful pause ☕",
    ],
  };
  const normalizeEmotion = (emo) => {
    if (!emo) return "Neutral";
    const e = emo.toLowerCase();

    if (e.includes("sad")) return "Sad";
    if (e.includes("anger") || e.includes("angry") || e.includes("mad"))
      return "Angry";
    if (e.includes("stress") || e.includes("pressure")) return "Stressed";
    if (e.includes("happy") || e.includes("good")) return "Happy";
    if (e.includes("fear")) return "Sad";
    if (e.includes("surprise")) return "Happy";
    if (e.includes("disgust")) return "Angry";

    return "Neutral";
  };

  const uid = localStorage.getItem("uid") || "guest";
  const LS_KEY = (k) => `${uid}_${k}`;
  const getFinalEmotion = () => {
    const faceRaw = localStorage.getItem(LS_KEY("lastFaceEmotion"));
    const textRaw = localStorage.getItem(LS_KEY("lastTextCategory"));

    const face = normalizeEmotion(faceRaw);
    const text = normalizeEmotion(textRaw);

    if (face && face !== "Neutral") return face;
    if (text && text !== "Neutral") return text;

    return "Neutral";
  };

  const emotion = getFinalEmotion();
  const [tipIndex, setTipIndex] = useState(0);

  const nextTip = () => {
    setTipIndex((prev) => (prev + 1) % wellnessTips[emotion].length);
  };
  return (
    <div className="well_page">
      <h2 className="page_title">Mental Wellness Recommendations</h2>

      <p className="intro">
        Based on your detected emotional state, here are some gentle suggestions:
      </p>

      <div className="well_box">
        <h3>Detected Emotion</h3>
        <p className="emotion_value">{emotion}</p>

        <div className="tip_card">
          <p>{wellnessTips[emotion][tipIndex]}</p>
        </div>

        <div className="btns">
          <button className="next_btn" onClick={nextTip}>
            Next Suggestion
          </button>
        </div>

        <p className="note">
          💡 Try following at least one suggestion today.
        </p>
      </div>
    </div>
  );
};

export default Recommendation;
