import React, { useState } from 'react'
import { 
  FaBrain,
  FaComments,
  FaChartLine,
  FaSignOutAlt,FaVideo
} from "react-icons/fa";
import "./AdminNav.css"
import { Outlet, useNavigate, useLocation } from 'react-router-dom';

const AdminNav = () => {
  const navigate = useNavigate();
  const location = useLocation();   // 👈 current URL path
  const [showLogoutPopup, setShowLogoutPopup] = useState(false);

  const menuItems = [
    { label:"Chatbot Content & Response", icon:<FaBrain />, path:"/admin" },
    // { label:"Camera Emotion", icon:<FaVideo />, path:"/admin/history" },
    { label:"Model Monitoring", icon:<FaComments />, path:"/admin/model" },
    { label:"Logs & Analytics", icon:<FaChartLine />, path:"/admin/logs" },
    { label:"Logout", icon:<FaSignOutAlt />, action:"logout" }
  ];

  const handleClick = (item)=>{
    if(item.action === "logout"){
      setShowLogoutPopup(true);
    } else {
      navigate(item.path);
    }
  }

  const confirmLogout = ()=>{
    setShowLogoutPopup(false);
    navigate("/");     
  }

  return (
    <div className="Admin_Layout">
      <div className="AdminNav_Parent">
        <h1>Admin</h1>

        <div className="AdminNav_Container">
          {menuItems.map((item)=>(
            <div className="AdminNav_Content" key={item.label}>
              <button
                className={location.pathname === item.path ? "active_menu" : ""}
                onClick={()=>handleClick(item)}
              >
                <span className="icon">{item.icon}</span>
                {item.label}
              </button>
            </div>
          ))}
        </div>
      </div>

      <div className="AdminNav_Outlet">
        <Outlet/>
      </div>

      {showLogoutPopup && (
        <div className="logout_modal">
          <div className="logout_box">
            <h3>Are you sure you want to logout?</h3>
            <div className="logout_btns">
              <button onClick={confirmLogout}>Yes</button>
              <button onClick={()=>setShowLogoutPopup(false)}>Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default AdminNav
